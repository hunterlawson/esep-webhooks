import requests

def lambda_handler(event, context):
    response = requests.get('http://www.google.com').text
    print(response)
    return response